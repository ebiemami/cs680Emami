A Simple Pass Through Shader Example
====================================

Building This Example
---------------------

*This example requires GLUT and GLEW* 

*On ubuntu they can be installed with this command*

>$ sudo apt-get install freeglut3-dev freeglut3 libglew1.6-dev

*On a Mac you can get these libraries with this command(using homebrew)*
>$ brew install freeglut glew

To build this example just 

>$ cd build

>$ make

*If you are using a Mac you will need to edit the makefile in the build directory*

The excutable will be put in bin
